﻿configuration AADC 
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName
    )

    Import-DscResource -ModuleName xTimeZone
    Import-DscResource -ModuleName xSystemSecurity
    Import-DscResource -ModuleName xComputerManagement
    
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }
        xTimeZone PacificTZ
        {
            IsSingleInstance = 'Yes'
            TimeZone = 'Pacific Standard Time'
        }
        xIEEsc DisableIEESCAdmins
        {
            UserRole = 'Administrators'
            isEnabled = $false
        }
        xIEEsc DisableIEESCUsers
        {
            UserRole = 'Users'
            isEnabled = $false
        }
        xComputer JoinDomain
        {
            Name = "AADC"
            DomainName = $DomainName
            Credential = $DomainCred
        }
    }
}