﻿configuration HV 
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName
    )

    Import-DscResource -ModuleName xTimeZone
    Import-DscResource -ModuleName xSystemSecurity
    Import-DscResource -ModuleName xComputerManagement
    Import-DscResource -ModuleName xHyper-V
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName xDhcpServer

    
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }
        xTimeZone PacificTZ
        {
            IsSingleInstance = 'Yes'
            TimeZone = 'Pacific Standard Time'
        }
        xIEEsc DisableIEESCAdmins
        {
            UserRole = 'Administrators'
            isEnabled = $false
        }
        xIEEsc DisableIEESCUsers
        {
            UserRole = 'Users'
            isEnabled = $false
        }
        xComputer JoinDomain
        {
            Name = "HV"
            DomainName = $DomainName
            Credential = $DomainCred
        }
        WindowsFeature InstallHyperV
        {
            Ensure = "Present"
            Name = "Hyper-V"
        }
        WindowsFeature InstallHyperVTools
        {
            Ensure = "Present"
            Name = "RSAT-Hyper-V-Tools"
        }
        WindowsFeature InstallDhcpServer
        {
            Ensure = "Present"
            Name = "DHCP"
        }
        WindowsFeature InstallDhcpServerTools
        {
            Ensure = "Present"
            Name = "RSAT-DHCP"
        }
        File VMsDirectory 
        {
            Ensure = "Present"
            Type = "Directory"
            DestinationPath = "$($env:SystemDrive)\VMs"
        }
        xVMSwitch LabSwitch
        {
            Ensure = "Present"
            Name = "LabSwitch"
            Type = 'Internal'
            DependsOn = "[WindowsFeature]InstallHyperV"
        }
        Script DownloadWin10Vhdx
        {
            SetScript = { 
                $Uri = "https://mitbclabresources.blob.core.windows.net/resources/Windows10Client.vhdx?sp=r&st=2022-10-25T20:30:32Z&se=2023-10-01T04:30:32Z&spr=https&sv=2021-06-08&sr=b&sig=IXmknXzRl2vV0usnfrPhQ2RBernD1eEXArYIPi4Nu4I%3D"
                $DestinationPath = "$($env:SystemDrive)\VMs\Windows10Client.vhdx"
                Start-BitsTransfer -Source $Uri -Destination $DestinationPath
            }
            TestScript = { Test-Path "$($env:SystemDrive)\VMs\Windows10Client.vhdx" }
            GetScript = { }
            DependsOn = "[File]VMsDirectory"
        }
        xVMHyperV Win10VM
        {
            Ensure = "Present"
            Name = "Windows 10 Client - Autopilot"
            VhdPath = "$($env:SystemDrive)\VMs\Windows10Client.vhdx"
            SwitchName = "LabSwitch"
            Path = "$($env:SystemDrive)\VMs\"
            StartupMemory = 8GB
            Generation = 2
            ProcessorCount = 2
            DependsOn = "[Script]DownloadWin10Vhdx", "[xVMSwitch]LabSwitch", "[Script]AuthorizeDhcpServer"
        }
		
		xVMHyperV Win10VM2
        {
            Ensure = "Present"
            Name = "Windows 10 Client - Enterprise"
            VhdPath = "$($env:SystemDrive)\VMs\Windows10Client.vhdx"
            SwitchName = "LabSwitch"
            Path = "$($env:SystemDrive)\VMs\"
            StartupMemory = 8GB
            Generation = 2
            ProcessorCount = 2
            DependsOn = "[Script]DownloadWin10Vhdx", "[xVMSwitch]LabSwitch", "[Script]AuthorizeDhcpServer"
        }
		
		xVMHyperV Win10VM3
        {
            Ensure = "Present"
            Name = "Windows 10 Client - Extra"
            VhdPath = "$($env:SystemDrive)\VMs\Windows10Client.vhdx"
            SwitchName = "LabSwitch"
            Path = "$($env:SystemDrive)\VMs\"
            StartupMemory = 8GB
            Generation = 2
            ProcessorCount = 2
            DependsOn = "[Script]DownloadWin10Vhdx", "[xVMSwitch]LabSwitch", "[Script]AuthorizeDhcpServer"
        }
        
        Script CheckPointVM
        {
            SetScript = { 
                Checkpoint-VM -Name "Windows 10 Client - Autopilot" -SnapshotName "Initial Deployment"
            }
            TestScript = { Test-Path "C:\VMs\Windows10Client*.avhdx" }
            GetScript = { }
            DependsOn = "[xVMHyperV]Win10VM"
        }

        xDhcpServerScope NatScope
        {
            ScopeId = "192.168.0.0"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallDhcpServer"
            IPStartRange = "192.168.0.5"
            IPEndRange = "192.168.0.254"
            Name = "Hyper-V VM Scope"
            SubnetMask = "255.255.255.0"
            LeaseDuration = ((New-TimeSpan -Hours 8).ToString())
            State = "Active"
            AddressFamily = "IPv4"
        }
        xDhcpServerOption NatScopeOptions
        {
            Ensure = "Present"
            DependsOn = "[xDhcpServerScope]NatScope"
            ScopeID = "192.168.0.0"
            AddressFamily = "IPv4"
            Router = "192.168.0.1"
            DnsServerIPAddress = ((Get-DnsClientServerAddress -AddressFamily IPv4 -InterfaceIndex (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.PrefixOrigin -ne "WellKnown" -and (Get-NetIPConfiguration -InterfaceIndex $_.InterfaceIndex).IPv4DefaultGateway -ne $null }).InterfaceIndex)[0].ServerAddresses[0])
        }
        Script SetupNAT
        {
            SetScript = {
                $index = (Get-NetAdapter -InterfaceDescription "Hyper-V*").ifIndex
                New-NetIPAddress -IPAddress "192.168.0.1" -PrefixLength 24 -InterfaceIndex $index
                New-NetNat -Name NATNetwork -InternalIPInterfaceAddressPrefix "192.168.0.0/24"
            }

            TestScript = { 
                if (Get-NetIPAddress | Where-Object { $_.IPAddress -eq "192.168.0.1" }) { $true } else { $false } 
            }
            GetScript = { }
            DependsOn = "[xVMSwitch]LabSwitch"
        }
        Script AuthorizeDhcpServer
        {
            SetScript = 
            {
                Invoke-Command -ScriptBlock { netsh dhcp add server hv.corp.litware.com 10.1.0.14 } -Credential $using:DomainCred -ComputerName ad
            }
            TestScript = { 
                $false
            }
            GetScript = { }
            DependsOn = "[xVMSwitch]LabSwitch", "[WindowsFeature]InstallDhcpServer", "[WindowsFeature]InstallDhcpServerTools", "[xComputer]JoinDomain"
        }
    }
}