configuration SCCM 
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName,
		[Parameter(Mandatory)][String]$SQLPass
    )

    Import-DscResource -ModuleName xTimeZone
    Import-DscResource -ModuleName xSystemSecurity
    Import-DscResource -ModuleName xComputerManagement
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
        
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }
        xTimeZone PacificTZ
        {
            IsSingleInstance = 'Yes'
            TimeZone = 'Pacific Standard Time'
        }
        xIEEsc DisableIEESCAdmins
        {
            UserRole = 'Administrators'
            isEnabled = $false
        }
        xIEEsc DisableIEESCUsers
        {
            UserRole = 'Users'
            isEnabled = $false
        }
		Script IESettings
        {
            SetScript = {
				if ((Test-Path "HKCU:\SOFTWARE\Microsoft\Internet Explorer\Main") -eq $false) 
				{ 
					New-Item -Path "HKCU:\SOFTWARE\Microsoft\Internet Explorer\Main" -Force
				}
				if ((Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3") -eq $false) 
				{ 
					New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" -Force
				}
				
				New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Internet Explorer\Main" -Name "Start Page" -Value "about:blank" -Force
                New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" -Name "2500" -Value "3" -PropertyType DWORD -Force
				New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" -Name "1803" -Value "0" -PropertyType DWORD -Force
			}
            TestScript = { 
				$false
			}
            GetScript = { }
            Credential = $DomainCred
        }
		File CreateFolderAutoPSInst
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "$($env:SystemDrive)\AutoPSInst"
		}
        xComputer JoinDomain
        {
            Name = "SCCM"
            DomainName = $DomainName
            Credential = $DomainCred
        }
		WindowsFeature NetFX35Install
        { 
            Ensure = "Present" 
            Name = "NET-Framework-Features"
        }
		WindowsFeature IISInstall
        { 
            Ensure = "Present" 
            Name = "Web-WebServer"
			IncludeAllSubFeature = $true
        }
		WindowsFeature IISToolsInstall
        { 
            Ensure = "Present" 
            Name = "Web-Mgmt-Tools"
			IncludeAllSubFeature = $true
        }
		WindowsFeature BITSInstall
        { 
            Ensure = "Present" 
            Name = "BITS"
			IncludeAllSubFeature = $true
        }
		WindowsFeature RDCInstall
        { 
            Ensure = "Present" 
            Name = "RDC"
        }
		WindowsFeature WASInstall
        { 
            Ensure = "Present" 
            Name = "WAS"
			IncludeAllSubFeature = $true
        }
		WindowsFeature WSUSToolsInstall
        { 
            Ensure = "Present" 
            Name = "UpdateServices-RSAT"
			IncludeAllSubFeature = $true
        }
		File CreateDownloadsFolder
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "$($env:SystemDrive)\downloads"
		}
		File CreateToolsFolder
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "$($env:SystemDrive)\Tools"
		}
		xRemoteFile DownloadFileSCCMFiles
		{
			Uri = "https://mitbootcamp.blob.core.windows.net/deployment-resources/sccm-scripts.zip?sp=r&st=2019-01-01T05:00:00Z&se=2099-12-31T05:00:00Z&spr=https&sv=2018-03-28&sig=qs%2B7QG1vAw51X5okwQfsm02IQJHQu723wVMHeVOzeds%3D&sr=b"
			DestinationPath = "$($env:SystemDrive)\downloads\sccm-scripts.zip"
			MatchSource = $true
			DependsOn = "[File]CreateDownloadsFolder"
		}
		Archive ExtractFiles
		{
			Ensure = "Present"
			Path = "$($env:SystemDrive)\downloads\sccm-scripts.zip"
			Destination = "$($env:SystemDrive)\AutoPSInst\"
			DependsOn = "[File]CreateFolderAutoPSInst"
		}
		File CopyInstallScript
		{
			Ensure = "Present"
			SourcePath = "$($env:SystemDrive)\AutoPSInst\Tools\deploy-sccm.ps1"
			DestinationPath = "$($env:SystemDrive)\Tools\deploy-sccm.ps1"
			Type = "File"
			MatchSource = $true
			DependsOn = "[Archive]ExtractFiles"
		}
    }
}