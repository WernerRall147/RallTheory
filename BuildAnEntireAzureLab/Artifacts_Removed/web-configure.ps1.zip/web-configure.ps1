﻿$folders = "C:\downloads", "C:\websites", "C:\websites\LitWareExpenses", "C:\websites\LitWarePortal"
$filesToDownload = "litware-expenses.zip", "litware-portal.zip"

configuration WEB 
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xTimeZone
    Import-DscResource -ModuleName xSystemSecurity
    Import-DscResource -ModuleName xComputerManagement
    Import-DscResource -ModuleName xWebAdministration
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }
        xTimeZone PacificTZ
        {
            IsSingleInstance = 'Yes'
            TimeZone = 'Pacific Standard Time'
        }
        xIEEsc DisableIEESCAdmins
        {
            UserRole = 'Administrators'
            isEnabled = $false
        }
        xIEEsc DisableIEESCUsers
        {
            UserRole = 'Users'
            isEnabled = $false
        }
        xComputer JoinDomain
        {
            Name = "WEB"
            DomainName = $DomainName
            Credential = $DomainCred
        }

        #Create Folders
        $num = 0;
        foreach ($folder in $folders)
        {
            $num++;
            File "CreateFolders$num"
            {
                Ensure = "Present"
                Type = "Directory"
                DestinationPath = $folder
            }
        }

        #Download files
        $num = 0;
        foreach ($file in $filesToDownload)
        {
            $num++;
            xRemoteFile "DownloadFile$num"
            {
                Uri = "https://mitbootcamp.blob.core.windows.net/labs/$file"
                DestinationPath = "C:\downloads\$file"
                MatchSource = $true
            }
        }

        #Extract LitWare Expenses App to Web Sites Folder
        Archive ExtractLitWareExpenses
        {
            Ensure = "Present"
            Path = "C:\downloads\litware-expenses.zip"
            Destination = "C:\websites\LitWareExpenses\"
        }

        #Extract LitWare Portal to Web Sites Folder
        Archive ExtractLitWarePortal
        {
            Ensure = "Present"
            Path = "C:\downloads\litware-portal.zip"
            Destination = "C:\websites\LitWarePortal\"
        }

        #Install IIS Role
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
            IncludeAllSubFeature = $true
        }

        #IIS Management Tools
        WindowsFeature IISManagementTools
        {
            Ensure = "Present"
            Name = "Web-Mgmt-Tools"
            DependsOn = '[WindowsFeature]IIS'
        }

        #Remove default IIS Site
        xWebsite RemoveDefaultWebSite
        {
            Ensure = "Absent"
            Name = "Default Web Site"
            PhysicalPath = "C:\inetpub\wwwroot"
        }

        #Create LitWare Expenses Web App
        xWebsite LitWareExpenses
        {
            Ensure = "Present"
            Name = "LitWare Expenses"
            PhysicalPath = "c:\websites\LitWareExpenses"
            AuthenticationInfo = MSFT_xWebAuthenticationInformation
            {
                Anonymous = $false
                Basic = $false
                Digest = $false
                Windows = $true
            }
            BindingInfo = MSFT_xWebBindingInformation
            {
                Protocol = "http"
                HostName = "expenses.corp.litware.com"

            }
        }

        #Create LitWare Portal Web App
        xWebsite LitWarePortal
        {
            Ensure = "Present"
            Name = "LitWare Portal"
            PhysicalPath = "c:\websites\LitWarePortal"
            AuthenticationInfo = MSFT_xWebAuthenticationInformation
            {
                Anonymous = $true
                Basic = $false
                Digest = $false
                Windows = $false
            }
            BindingInfo = MSFT_xWebBindingInformation
            {
                Protocol = "http"
                HostName = "portal.corp.litware.com"

            }
        }

    }
}